# 🎭 RP Telegram Bot

Telegram-бот для рольової гри з подачею заявок на вступ.

## Можливості

- `/start` — головне меню
- правила та інформація про ролівку
- багатокрокова заявка через FSM
- попередній перегляд перед відправкою
- SQLite для збереження заявок
- перевірка статусу заявки
- повідомлення адміністраторам про нову заявку
- кнопки адміністратора:
  - ✅ прийняти
  - ❌ відхилити
  - 🔎 додатковий розгляд
- автоматичне повідомлення користувача про рішення
- Docker / docker-compose

Проєкт використовує aiogram 3.30.0. У цій версії `Router`/`Dispatcher` є базовою схемою маршрутизації, а FSM призначена для багатокрокового збору даних.

## 1. Створити бота

В Telegram відкрий `@BotFather`:

1. `/newbot`
2. задай назву;
3. задай username;
4. скопіюй токен.

**Не публікуй токен у GitHub.**

## 2. Дізнатися свій Telegram ID

Можна використати будь-якого бота, який показує Telegram ID, або отримати його через власну логіку бота.

У `.env` потрібно вказати ID адміністраторів через кому:

```env
ADMIN_IDS=123456789,987654321
```

## 3. Локальний запуск

Потрібен Python 3.12+.

```bash
git clone https://github.com/YOUR_USERNAME/rp-telegram-bot.git
cd rp-telegram-bot

python -m venv .venv
```

Linux/macOS:

```bash
source .venv/bin/activate
```

Windows PowerShell:

```powershell
.venv\Scripts\Activate.ps1
```

Встанови залежності:

```bash
pip install -r requirements.txt
```

Створи `.env`:

```bash
cp .env.example .env
```

Windows:

```powershell
copy .env.example .env
```

Встав токен і Telegram ID адміністраторів.

Запуск:

```bash
python main.py
```

## 4. GitHub

```bash
git init
git add .
git commit -m "Initial RP Telegram bot"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/rp-telegram-bot.git
git push -u origin main
```

Переконайся, що `.env` не потрапив у репозиторій.

## 5. Docker

Створи `.env`, потім:

```bash
docker compose up -d --build
```

Логи:

```bash
docker compose logs -f bot
```

Зупинка:

```bash
docker compose down
```

База зберігається в `./data/bot.db`.

## 6. Що варто змінити під свою ролівку

Найпростіше — відредагувати `.env`:

- `RULES_TEXT`
- `ABOUT_TEXT`

Питання анкети знаходяться в:

```text
bot/handlers/application.py
```

Головне меню і кнопки:

```text
bot/keyboards.py
```

Тексти та бізнес-логіка адмінки:

```text
bot/handlers/admin.py
```

## 7. Безпека

- токен Telegram-бота тримай тільки в `.env` або секретах хостингу;
- не коміть `.env`;
- обмежуй `ADMIN_IDS` тільки своїми Telegram ID;
- перед production бажано перейти з SQLite на PostgreSQL, якщо заявок стане багато;
- для production-розгортання можна використовувати webhook замість long polling.

## Структура

```text
rp-telegram-bot/
├── bot/
│   ├── database/
│   │   └── db.py
│   ├── handlers/
│   │   ├── admin.py
│   │   ├── application.py
│   │   └── common.py
│   ├── config.py
│   ├── keyboards.py
│   └── states.py
├── data/
├── .env.example
├── .gitignore
├── Dockerfile
├── docker-compose.yml
├── main.py
├── README.md
└── requirements.txt
```
