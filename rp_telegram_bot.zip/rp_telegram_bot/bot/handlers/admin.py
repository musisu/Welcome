from aiogram import Router, F
from aiogram.types import Bot, CallbackQuery, Message

from bot.config import settings
from bot.database.db import get_application, update_application_status
from bot.keyboards import admin_keyboard, main_menu

router = Router()


def is_admin(user_id: int) -> bool:
    return user_id in settings.admin_ids


async def send_application_to_admins(bot: Bot, text: str, application_id: int) -> None:
    for admin_id in settings.admin_ids:
        try:
            await bot.send_message(
                admin_id,
                text,
                reply_markup=admin_keyboard(application_id),
            )
        except Exception:
            # One unavailable admin must not prevent delivery to the others.
            continue


@router.message(F.text == "/admin")
async def admin_help(message: Message) -> None:
    if not is_admin(message.from_user.id):
        await message.answer("⛔ У тебе немає доступу.")
        return

    await message.answer(
        "<b>🛡 Адмін-панель</b>\n\n"
        "Нові заявки надходитимуть сюди автоматично.\n"
        "Кнопками під заявкою можна змінити її статус."
    )


@router.callback_query(F.data.startswith("admin:"))
async def admin_action(callback: CallbackQuery) -> None:
    if not is_admin(callback.from_user.id):
        await callback.answer("⛔ Немає доступу", show_alert=True)
        return

    parts = callback.data.split(":")
    if len(parts) != 3:
        await callback.answer("Некоректна команда", show_alert=True)
        return

    action, application_id_raw = parts[1], parts[2]

    try:
        application_id = int(application_id_raw)
    except ValueError:
        await callback.answer("Некоректний ID", show_alert=True)
        return

    row = await get_application(application_id)
    if not row:
        await callback.answer("Заявку не знайдено", show_alert=True)
        return

    status_map = {
        "accept": ("accepted", "✅ Заявку прийнято."),
        "reject": ("rejected", "❌ Заявку відхилено."),
        "review": ("review", "🔎 Заявку переведено на додатковий розгляд."),
    }

    if action not in status_map:
        await callback.answer("Невідома дія", show_alert=True)
        return

    status, admin_text = status_map[action]
    await update_application_status(application_id, status)

    user_text = {
        "accepted": f"🎉 Твою заявку <b>#{application_id}</b> прийнято! Вітаємо.",
        "rejected": f"❌ Твою заявку <b>#{application_id}</b> відхилено.",
        "review": f"🔎 Твою заявку <b>#{application_id}</b> перевели на додатковий розгляд.",
    }[status]

    try:
        await callback.bot.send_message(row["user_id"], user_text, reply_markup=main_menu())
    except Exception:
        pass

    await callback.answer(admin_text)

    if callback.message:
        await callback.message.edit_reply_markup(reply_markup=None)
        await callback.message.answer(
            f"{admin_text}\n\nЗаявка #{application_id}: статус <b>{status}</b>."
        )
